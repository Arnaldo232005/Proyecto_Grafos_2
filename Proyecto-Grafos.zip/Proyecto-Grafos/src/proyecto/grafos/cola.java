/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.grafos;

/**
 *
 * @author valle
 */
public class cola {
    Nodo frente;
    Nodo finalCola;
    int tamaño;
    public cola(){
        this.frente=null;
        this.finalCola=null;
        this.tamaño=0;
    }
    public void encolar(Estacion info){
        Nodo nuevoNodo=new Nodo(info,null);
        if (finalCola!=null){
            finalCola.sig=nuevoNodo;
        }
        finalCola=nuevoNodo;
        if(frente==null){
            frente=nuevoNodo;
        }
        tamaño++;   
    }
    public Estacion desencolar(){
        if (frente==null){
           throw new IllegalStateException("La cola está vacía"); 
        }
        Estacion info=frente.info;
        frente=frente.sig;
        if (frente==null){
            finalCola=null;
        }
        tamaño--;
        return info;
        
    }
    public Estacion verFrente(){
        if(frente==null){
            throw new IllegalStateException("La cola está vacía");
            
        }
        return frente.info;
    }
    public boolean estaVacía(){
        return tamaño==0;
    }
    public int tamaño(){
        return tamaño;
    }
    
}
