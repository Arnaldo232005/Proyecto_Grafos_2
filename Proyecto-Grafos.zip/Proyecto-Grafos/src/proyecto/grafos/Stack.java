/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.grafos;

/**
 *
 * @author valle
 */
public class Stack {//clase pilas
    class Nodo{//crear clase nodo dentro de pilas
        Estacion info;//crear informacion de nodo estacion
        Nodo sig;//crear nodo siguiente del nodo
    }
    private Nodo raiz;//crear nodo raiz
    public Stack(){//inicializar constructor
        raiz=null;//raiz es igual a null
    }
    public void insertar(Estacion x){//método insertar
        Nodo nuevo;//crear nodo nuevo
        nuevo=new Nodo();
        nuevo.info=x;//la informacion del nodo nuevo es igual a x
        if(raiz==null){// si raiz es igual a null
            nuevo.sig=null;//nodo siguiente del nodo nuevo es igual a null
            raiz=nuevo;//raiz es igual al nodo nuevo
        }
        else{
            nuevo.sig=raiz;//nodo siguiente del nodo es igual a raiz
            raiz=nuevo;//raiz es igual a nuevo
        }
    }
    public Estacion extraer(){//función extraer con retorno estacion
        if(raiz!=null){//si raiz es distinto a null
            Estacion informacion=raiz.info;//crear estacion informacion y asignarle el valor de la informacion de raiz
            raiz=raiz.sig;//raiz es igual a nodo siguiente de raiz
            return informacion;//retornar informacion
        }
        else{
            return null;//retornar null
        }
    }
    Boolean es_vacio(){//función es vacío
        return raiz==null;//retornar raiz igual a null
    }
    
}
