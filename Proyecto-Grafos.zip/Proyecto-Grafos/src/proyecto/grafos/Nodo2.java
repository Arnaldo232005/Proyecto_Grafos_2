/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.grafos;

/**
 *
 * @author valle
 */
public class Nodo2 {//clase Nodo2
    Nodo2 sig;//crear nod siguiente
    String info;//crear informacion del nodo string

public Nodo2(String i,Nodo2 s){//inicializar constructor
    info=i;//la informacion del nodo es igual a i
    sig=s;//el nodo siguiente del nodo es igual a s
}
public String getInfo(){//mostar la informacion del nodo
    return info;
}
public void setInfo(String info){//añadir la informacion del nodo
    this.info=info;
}
public Nodo2 getSig(){//mostrar el nodo siguiente del nodo
    return sig;
}
public void setSig(Nodo2 sig){//añadir el nodo siguiente del nodo
    this.sig=sig;
}
}
