/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.grafos;

/**
 *
 * @author valle
 */
public class Lista {//clase Lista
    Nodo2 pLast;//crear nodo último
    Nodo2 pFirst;//crear nodo primero
    public Lista(){//inicializar constructor
        pFirst=null;
        pLast=null;
    }
    public void insertar(String info){//método insertar en la lista
        Nodo2 pAux = new Nodo2(info,null);//crear nodo auxiliar
        if (pFirst==null){//si nodo primero es igual a null
            pLast=pAux;//nodo primero y último son iguales al nodo auxiliar
            pFirst=pLast;
        }
        else {
            pLast.setSig(pAux);//si no nodo auxiliar se añade a la lista y se convierte en el nodo último
            pLast=pAux;   
        }
    }
    Boolean buscar(String x){//funcion buscar con retorno booleano
        Nodo2 pAux=pFirst;//nodo auxiliar es igual a nodo primero
        Boolean result=false;
        while(pAux!=null){//mientras nodo auxiliar sea distinto a null
            if ((pAux.info).equals(x)){//si el nombre de la estacion del nodo auxiliar es igual al string x
                result=true;//retornar verdadero
            }
            pAux=pAux.sig;//nodo auxiliar es igual a siguiente
        }
        return result;//retornar falso
        
    }

}
    
