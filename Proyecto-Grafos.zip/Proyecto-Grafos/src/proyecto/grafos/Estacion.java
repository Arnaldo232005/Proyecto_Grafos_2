/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.grafos;

import org.graphstream.graph.Graph;

/**
 *
 * @author valle
 */

   public class Estacion{
    ListaDeConexiones conexiones = new ListaDeConexiones(); 
    String Linea;
    Boolean sucursal = false;
    String nombre;
    ListaDeConexiones coberturaDeSucursal=new ListaDeConexiones();
    Boolean DFS(Estacion origen, int t) {//Busqueda por DFS
    Stack pilas = new Stack();
    Lista visitados=new Lista();
    
    pilas.insertar(origen);
    visitados.insertar(origen.nombre);
    int n=0;

    while (!pilas.es_vacio() && n<=t) {
        Estacion nodoActual = pilas.extraer();
        
        // Verificar si la estación actual es una sucursal
        if (nodoActual.sucursal) {
            return false; 
        }
        
        coberturaDeSucursal.insertar(nodoActual);
        
        // Recorrer las conexiones de la estación actual

        for (int i = 0; i < nodoActual.conexiones.tamaño(); i++) {
            Estacion w = nodoActual.conexiones.busquedaPorIndice(i);
            System.out.println(w.nombre);
            // Solo insertar en la pila si no ha sido visitada
            if (!visitados.buscar(w.nombre)) {
                pilas.insertar(w);
                visitados.insertar(w.nombre);
            }}
        n+=1;
        

    }
    return true; // Cambiar el retorno final según la lógica deseada
}
    Boolean BFS(Estacion origen,int t){//Busqueda BFS
        cola cola=new cola();
        cola cola2=new cola();
        cola.encolar(origen);
        cola2.encolar(origen);
        Lista visitados=new Lista();
        int n=0;
        int j=origen.conexiones.tamaño();
        //buscar estaciones que ya han sido repetidas para reducir el perimetro

        visitados.insertar(origen.getNombre());
        int z=t*j;
        while(!cola.estaVacía() && n<=z){
            Estacion nodoActual=cola.desencolar();
            coberturaDeSucursal.insertar(nodoActual);
     
            // Verificar si la estación actual es una sucursal
            if(nodoActual.sucursal==true){
                return false;
            }  
                // Recorrer las conexiones de la estación actual
                for (int i = 0; i < nodoActual.conexiones.tamaño(); i++){
                    Estacion w = nodoActual.conexiones.busquedaPorIndice(i);
                    
                    
                    // Solo insertar en la pila si no ha sido visitada
                    if(!visitados.buscar(w.getNombre())){
                        visitados.insertar(w.getNombre());
                        cola.encolar(w);
                    }
                    
                }
                n+=1;
            
        }
        return true;// Cambiar el retorno final según la lógica deseada
    }


        
        
    Boolean aniadirSucursal(Estacion x,int t){
       if (BFS(x,t)==true){
           x.sucursal=true;
           return true;      
       } 
       return false;
    }
    public String getNombre(){//mostar el nombre del nodo
    return nombre;
}
    public void setNombre(Estacion x){//añadir el nombre del nodo
    x.nombre=nombre;
    }
    
   public void conectarEstaciones (Estacion x, Estacion y){
       (x.conexiones).insertar(y);
       (y.conexiones).insertar(x);
       
   }}
     
           
           
       
       
      

       
       
       
   
    

