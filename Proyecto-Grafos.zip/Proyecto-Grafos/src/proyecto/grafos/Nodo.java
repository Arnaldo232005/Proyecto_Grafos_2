/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.grafos;

/**
 *
 * @author valle
 */
public class Nodo {//clase nodo
    Nodo sig;//crear nodo siguiente
    Estacion info;//crear informacion de nodo estacion

public Nodo(Estacion i,Nodo s){//inicializar constructor
    info=i;//la informacion del nodo es igual a i
    sig=s;//el nodo siguiente del nodo es igual a s

}
public Estacion getInfo(){//mostar la información del nodo
    return info;
}
public void setInfo(Estacion info){//añadir la información del nodo
    this.info=info;
}
public Nodo getSig(){//mostrar el nodo sigiuente del nodo
    return sig;
}
public void setSig(Nodo sig){//añadir el nodo siguiente del nodo
    this.sig=sig;
}
}
