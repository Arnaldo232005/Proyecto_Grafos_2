/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.grafos;

/*
 *
 * @author valle
 */
public class ListaDeConexiones {//clase ListaDeConexiones
    Nodo pLast;//crear nodo último
    Nodo pFirst;//crear nodo primero
    public ListaDeConexiones(){//Inicializar constructor
        pFirst=null;
        pLast=null;
    }
    public void insertar(Estacion info){//método insertar en la lista
        Nodo pAux = new Nodo(info, null);//crear nodo auxiliar
        pAux.info=info;//establecer contenido del nodo
        if (pFirst==null){//si nodo primero es igual a null
            pLast=pAux;//nodo primero y último son iguales al nodo auxiliar
            pFirst=pLast;
        }
        else {
            pLast.setSig(pAux);//si no nodo auxiliar se añade a la lista y se convierte en el nodo último
            pLast=pAux;   
        }
    }
    Estacion buscar(String x){//funcion bucar con retorno a la estacion
        Nodo pAux=pFirst;//nodo auxiliar es igual a nodo primero
        while(pAux!=null){//mientras nodo auxiliar sea distinto a null
            if ((pAux.info.nombre).equals(x)){//si el nombre de la estacion del nodo auxiliar es igual al string x
                return pAux.info;//se retorna la estacion
            }
            pAux=pAux.sig;//nodo auxiliar es igual a siguiente
        }
        return null;//retornar null
        
    }
    Boolean buscarD(String x){//funcion buscar con retorno booleano
        Nodo pAux=pFirst;//nodo auxiliar es igual a nodo primero
        while(pAux!=null){//mientras nodo auxiliar sea distinto a null
            if ((pAux.info.nombre).equals(x)){//si el nombre de la estacion del nodo auxiliar es igual al string x
                return true;//se retorna verdadero
            }
            pAux=pAux.sig;//nodo auxiliar es igual a siguiente
        }
        return false;//retornar 
        
    }
    int tamaño(){
        int n=0;
        Nodo pAux=this.pFirst;
        while(pAux!=null){
            n+=1;
            pAux=pAux.sig;
            
            
        }
        return n;
        
    }
    int indiceDeEstacion(Estacion x){//Otorgar indice de la estacion x de la lista
        int n=0;
        Nodo pAux=this.pFirst;
        while(pAux!=null){
            if(pAux.info==x){
                return n;
            }
            n+=1;
            pAux=pAux.sig;
            
            
        }
        
    return -10;    
    }
    Estacion busquedaPorIndice(int x){//Buscar estacion con base el indice x
        int n=0;
        Nodo pAux=this.pFirst;
        while(pAux!=null){
            if(n==x){
                return pAux.info;
            }
            pAux=pAux.sig;
            n+=1;
    }
    return null;}
}

